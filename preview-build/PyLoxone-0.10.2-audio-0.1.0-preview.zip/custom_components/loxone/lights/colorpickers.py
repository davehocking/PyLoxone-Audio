import logging
from functools import cached_property

import homeassistant.util.color as color_util
from homeassistant.components.light import (ATTR_BRIGHTNESS,
                                            ATTR_COLOR_TEMP_KELVIN,
                                            ATTR_HS_COLOR, ColorMode,
                                            LightEntity)
from homeassistant.const import STATE_UNKNOWN
from homeassistant.helpers.device_registry import DeviceInfo

from .. import LoxoneEntity
from ..const import DOMAIN, SENDDOMAIN
from ..helpers import (get_or_create_device, hass_to_lox, lox_to_hass,
                       parse_lox_color)

_LOGGER = logging.getLogger(__name__)

_COLOR_VALUE_COUNT = {"hsv": 3, "temp": 2}


def _color_temp_range(details: dict) -> tuple[int, int]:
    """Kelvin range from details.TWMin/TWMax (spec default 2700/6500)."""
    details = details or {}
    return int(details.get("TWMin") or 2700), int(details.get("TWMax") or 6500)


def _parse_color(text: str, name) -> list[int | float] | None:
    """Parse an ``hsv(...)`` / ``temp(...)`` state; None (and a warning) if invalid.

    Replaces an ``eval`` that ran Miniserver data as Python code.
    """
    try:
        kind, values = parse_lox_color(text)
    except ValueError:
        values = None
    else:
        if len(values) != _COLOR_VALUE_COUNT[kind]:
            values = None
    if values is None:
        _LOGGER.warning("Ignoring invalid color of %s: %r", name, text)
    return values


class TunableWhiteLight(LoxoneEntity, LightEntity):
    _attr_max_color_temp_kelvin = 6500
    _attr_min_color_temp_kelvin = 2000

    _attr_supported_color_modes: set[ColorMode] = {ColorMode.COLOR_TEMP}
    _attr_available = False

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        """Initialize the Tunable White Light."""
        self._attr_state = STATE_UNKNOWN
        self._attr_is_on = STATE_UNKNOWN
        self._attr_unique_id = self.uuidAction
        self._attr_color_mode = ColorMode.UNKNOWN
        self._color_uuid = kwargs.get("states", {}).get("color", None)
        (
            self._attr_min_color_temp_kelvin,
            self._attr_max_color_temp_kelvin,
        ) = _color_temp_range(kwargs.get("details"))

        self._async_add_devices = kwargs["async_add_devices"]
        self._light_controller_id = kwargs.get("lightcontroller_id", None)
        self._light_controller_name = kwargs.get("lightcontroller_name", None)

        self._name = self._attr_name
        if self._light_controller_name:
            self._attr_name = f"{self._light_controller_name}-{self._attr_name}"

        if self._light_controller_id:
            self.type = "LightControllerV2"
            self._attr_entity_registry_enabled_default = kwargs.get("enabled_default", True)
            self._attr_device_info = get_or_create_device(
                self._light_controller_id, self.name, self.type, self.room
            )
        else:
            self.type = "ColorPickerV2"
            self._attr_device_info = get_or_create_device(
                self._light_controller_id, self.name, self.type, self.room
            )

    @cached_property
    def unique_id(self) -> str:
        """Return a unique ID."""
        return self._attr_unique_id

    @property
    def is_on(self) -> bool:
        return True if self._attr_brightness and self._attr_brightness > 0 else False

    async def async_turn_off(self) -> None:
        self.hass.bus.async_fire(
            SENDDOMAIN, dict(uuid=self.uuidAction, value="setBrightness/0")
        )
        self.async_schedule_update_ha_state()

    async def async_turn_on(self, **kwargs) -> None:
        if ATTR_COLOR_TEMP_KELVIN in kwargs:
            self._attr_color_temp_kelvin = kwargs[ATTR_COLOR_TEMP_KELVIN]
        if ATTR_BRIGHTNESS in kwargs:
            self._attr_brightness = kwargs[ATTR_BRIGHTNESS]
        if ATTR_COLOR_TEMP_KELVIN in kwargs or ATTR_BRIGHTNESS in kwargs:
            # temp() needs both parts - no Kelvin value received yet means
            # the range minimum, never None.
            kelvin = (
                getattr(self, "_attr_color_temp_kelvin", None)
                or self._attr_min_color_temp_kelvin
            )
            brightness = self._attr_brightness or 255
            self.hass.bus.async_fire(
                SENDDOMAIN,
                dict(
                    uuid=self.uuidAction,
                    value="temp({:g},{})".format(hass_to_lox(brightness), kelvin),
                ),
            )
        else:
            self.hass.bus.async_fire(
                SENDDOMAIN,
                dict(
                    uuid=self.uuidAction,
                    value="setBrightness/{:g}".format(
                        hass_to_lox(self._attr_brightness or 255)
                    ),
                ),
            )

    async def event_handler(self, e):
        request_update = False
        if self._color_uuid in e.data:
            _color = e.data[self._color_uuid]

            if _color.startswith("temp"):
                _color = _parse_color(_color, self.name)
                if _color is None:
                    return
                self._attr_color_mode = ColorMode.COLOR_TEMP
                self._attr_color_temp_kelvin = _color[1]
                self._attr_brightness = round(255 * _color[0] / 100)
                request_update = True
            elif _color.startswith("hsv"):
                if _color == "hsv(0,0,0)":
                    self._attr_brightness = 0
                else:
                    _LOGGER.warning("hsv not supported for TunableWhiteLight")
            else:
                _LOGGER.error("Not handled command -> %s", _color)

        if request_update:
            if not self._attr_available:
                self._attr_available = True
            self.async_schedule_update_ha_state()

    @cached_property
    def icon(self):
        """Return the sensor icon."""
        return "mdi:lightbulb"


class RGBColorPicker(LoxoneEntity, LightEntity):
    __color_mode_reported = True
    _attr_max_color_temp_kelvin = 6500
    _attr_min_color_temp_kelvin = 2000
    _attr_available = False

    _attr_supported_color_modes: set[ColorMode] = {
        ColorMode.COLOR_TEMP,
        ColorMode.HS,
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        """Initialize the LumiTech."""
        self._attr_unique_id = self.uuidAction
        self._attr_color_mode = ColorMode.UNKNOWN
        self._color_uuid = kwargs.get("states", {}).get("color", None)
        self._sequence_uuid = kwargs.get("states", {}).get("sequence", None)
        (
            self._attr_min_color_temp_kelvin,
            self._attr_max_color_temp_kelvin,
        ) = _color_temp_range(kwargs.get("details"))

        self._async_add_devices = kwargs["async_add_devices"]
        self._light_controller_id = kwargs.get("lightcontroller_id", None)
        self._light_controller_name = kwargs.get("lightcontroller_name", None)

        self._name = self._attr_name
        if self._light_controller_name:
            self._attr_name = f"{self._light_controller_name}-{self._attr_name}"

        if self._light_controller_id:
            self.type = "LightControllerV2"
            self._attr_entity_registry_enabled_default = kwargs.get("enabled_default", True)
            self._attr_device_info = get_or_create_device(
                self._light_controller_id, self.name, self.type, self.room
            )
        else:
            self.type = "ColorPickerV2"
            self._attr_device_info = get_or_create_device(
                self._light_controller_id, self.name, self.type, self.room
            )

    @cached_property
    def unique_id(self) -> str:
        """Return a unique ID."""
        return self._attr_unique_id

    @property
    def is_on(self) -> bool:
        return True if self._attr_brightness and self._attr_brightness > 0 else False

    async def async_turn_off(self) -> None:
        self.hass.bus.async_fire(
            SENDDOMAIN, dict(uuid=self.uuidAction, value="setBrightness/0")
        )
        self.async_schedule_update_ha_state()

    async def async_turn_on(self, **kwargs) -> None:
        if ATTR_BRIGHTNESS in kwargs:
            self._attr_brightness = kwargs[ATTR_BRIGHTNESS]
        else:
            self._attr_brightness = self._attr_brightness or 255
        if ATTR_HS_COLOR in kwargs:
            r, g, b = color_util.color_hs_to_RGB(
                kwargs[ATTR_HS_COLOR][0], kwargs[ATTR_HS_COLOR][1]
            )
            h, s, v = color_util.color_RGB_to_hsv(r, g, b)
            self.hass.bus.async_fire(
                SENDDOMAIN,
                dict(
                    uuid=self.uuidAction,
                    value="hsv({},{},{})".format(
                        h, s, hass_to_lox(self._attr_brightness)
                    ),
                ),
            )
        elif ATTR_COLOR_TEMP_KELVIN in kwargs:
            self._attr_color_temp_kelvin = kwargs[ATTR_COLOR_TEMP_KELVIN]
            self.hass.bus.async_fire(
                SENDDOMAIN,
                dict(
                    uuid=self.uuidAction,
                    value="temp({},{})".format(
                        hass_to_lox(self._attr_brightness), self._attr_color_temp_kelvin
                    ),
                ),
            )

        elif ATTR_BRIGHTNESS in kwargs:
            if self._attr_color_mode == ColorMode.HS:
                self.hass.bus.async_fire(
                    SENDDOMAIN,
                    dict(
                        uuid=self.uuidAction,
                        value="hsv({},{},{})".format(
                            self.hs_color[0],
                            self.hs_color[1],
                            hass_to_lox(self._attr_brightness),
                        ),
                    ),
                )
            elif self._attr_color_mode == ColorMode.COLOR_TEMP:
                self.hass.bus.async_fire(
                    SENDDOMAIN,
                    dict(
                        uuid=self.uuidAction,
                        value="temp({},{})".format(
                            hass_to_lox(self._attr_brightness),
                            self._attr_color_temp_kelvin,
                        ),
                    ),
                )
            else:
                # No colour context yet: pure brightness, nothing else.
                self.hass.bus.async_fire(
                    SENDDOMAIN,
                    dict(
                        uuid=self.uuidAction,
                        value="setBrightness/{:g}".format(
                            hass_to_lox(self._attr_brightness)
                        ),
                    ),
                )
        else:
            self.hass.bus.async_fire(SENDDOMAIN, dict(uuid=self.uuidAction, value="setBrightness/{}".format(
                        hass_to_lox(self._attr_brightness))))

    async def event_handler(self, e):
        request_update = False
        if self._color_uuid in e.data:
            _color = e.data[self._color_uuid]

            if _color.startswith("hsv"):
                _color = _parse_color(_color, self.name)
                if _color is None:
                    return
                self._attr_color_mode = ColorMode.HS
                self._attr_hs_color = (_color[0], _color[1])
                self._attr_brightness = lox_to_hass(_color[2])
                request_update = True
            elif _color.startswith("temp"):
                _color = _parse_color(_color, self.name)
                if _color is None:
                    return
                self._attr_color_mode = ColorMode.COLOR_TEMP
                self._attr_color_temp_kelvin = _color[1]
                self._attr_hs_color = None
                self._attr_brightness = round(255 * _color[0] / 100)
                request_update = True
            else:
                _LOGGER.error("Not handled command -> %s", _color)

        if request_update:
            if not self._attr_available:
                self._attr_available = True
            self.async_schedule_update_ha_state()

    @cached_property
    def icon(self):
        """Return the sensor icon."""
        return "mdi:eyedropper-variant"


class LumiTech(RGBColorPicker):
    """Representation of a Loxone LumiTech Dimmer."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        """Initialize the LumiTech."""
        if self._light_controller_id:
            self.type = "LightControllerV2"
            self._attr_entity_registry_enabled_default = kwargs.get("enabled_default", True)
            self._attr_device_info = get_or_create_device(
                self._light_controller_id, self.name, self.type, self.room
            )
        else:
            self.type = "LumiTech"
            self._attr_device_info = get_or_create_device(
                self.unique_id, self.name, self.type, self.room
            )
